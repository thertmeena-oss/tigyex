import type { ChatRequest } from '../types';

/** The only thing the UI knows about. Add OpenAI/Anthropic/Gemini adapters on the SERVER, behind /api/chat. */
export interface AIProvider {
  name: string;
  sendMessage(r: ChatRequest, signal?: AbortSignal): Promise<string>;
  streamMessage(r: ChatRequest, onToken: (t: string) => void, signal?: AbortSignal): Promise<void>;
  analyzeImage(r: ChatRequest, signal?: AbortSignal): Promise<string>;
}

const abortErr = () => new DOMException('Aborted', 'AbortError');
const sleep = (ms: number, s?: AbortSignal) =>
  new Promise<void>((res, rej) => {
    const t = setTimeout(res, ms);
    s?.addEventListener('abort', () => { clearTimeout(t); rej(abortErr()); });
  });

/** Local placeholder. Does NOT call any model and says so in every reply. */
export class MockAIProvider implements AIProvider {
  name = 'Mock (local, no AI)';
  async sendMessage(r: ChatRequest, s?: AbortSignal) { let out = ''; await this.streamMessage(r, (t) => (out += t), s); return out; }
  analyzeImage(r: ChatRequest, s?: AbortSignal) { return this.sendMessage(r, s); }
  async streamMessage(r: ChatRequest, on: (t: string) => void, s?: AbortSignal) {
    const last = r.messages[r.messages.length - 1];
    const n = last?.attachments?.length ?? 0;
    let text = `This is a local placeholder reply. No AI model is connected, so TIGYEX cannot really answer "${last?.content.slice(0, 80) ?? ''}".`;
    if (n) text += ` ${n} attachment(s) were attached but not analyzed.`;
    if (r.webSearch) text += ' Web Search is on, but no search backend is connected.';
    text += ' Set an API endpoint in Settings once your backend implements POST /api/chat.';
    for (const w of text.split(/(\s+)/)) {
      if (s?.aborted) throw abortErr();
      on(w);
      await sleep(25, s);
    }
  }
}

/**
 * Contract: POST {endpoint}/api/chat, JSON body = ChatRequest, response = streamed plain text.
 * Files: send via multipart or an upload endpoint from Attachment.file; dataUrl is only a preview.
 */
export class BackendProvider implements AIProvider {
  name = 'TIGYEX backend';
  constructor(private endpoint: string) {}
  async sendMessage(r: ChatRequest, s?: AbortSignal) { let out = ''; await this.streamMessage(r, (t) => (out += t), s); return out; }
  analyzeImage(r: ChatRequest, s?: AbortSignal) { return this.sendMessage(r, s); }
  async streamMessage(r: ChatRequest, on: (t: string) => void, s?: AbortSignal) {
    const res = await fetch(`${this.endpoint.replace(/\/$/, '')}/api/chat`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(r), signal: s,
    });
    if (!res.ok || !res.body) throw new Error(`Backend responded ${res.status}`);
    const rd = res.body.getReader(); const dec = new TextDecoder();
    for (;;) { const { done, value } = await rd.read(); if (done) break; on(dec.decode(value, { stream: true })); }
  }
}

export const getProvider = (endpoint: string): AIProvider => (endpoint.trim() ? new BackendProvider(endpoint.trim()) : new MockAIProvider());
