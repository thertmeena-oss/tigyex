export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
export const formatSize = (b: number) => (b < 1048576 ? `${Math.max(1, Math.round(b / 1024))} KB` : `${(b / 1048576).toFixed(1)} MB`);
export async function resizeImage(f: File, max = 1280): Promise<string> {
  const bmp = await createImageBitmap(f);
  const s = Math.min(1, max / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas');
  c.width = Math.round(bmp.width * s); c.height = Math.round(bmp.height * s);
  c.getContext('2d')!.drawImage(bmp, 0, 0, c.width, c.height);
  bmp.close();
  return c.toDataURL(f.type === 'image/png' ? 'image/png' : 'image/jpeg', 0.85);
}
