import { useState } from 'react';
import { Pencil, Plus, Search, Settings as Cog, Trash2, X } from 'lucide-react';
import type { Conversation } from '../types';

interface P { convs: Conversation[]; activeId: string | null; open: boolean; onClose: () => void; onNew: () => void; onSelect: (id: string) => void; onRename: (id: string, t: string) => void; onDelete: (id: string) => void; onSettings: () => void }
export default function Sidebar({ convs, activeId, open, onClose, onNew, onSelect, onRename, onDelete, onSettings }: P) {
  const [q, setQ] = useState('');
  const list = convs.filter((c) => c.title.toLowerCase().includes(q.toLowerCase())).sort((a, b) => b.updatedAt - a.updatedAt);
  return (
    <>
      {open && <div className="scrim" onClick={onClose} aria-hidden="true" />}
      <aside className={`side ${open ? 'open' : ''}`} aria-label="Sidebar">
        <div className="brand"><span className="wordmark">TIGYEX</span><button className="close" aria-label="Close sidebar" onClick={onClose}><X size={20} /></button></div>
        <button className="primary" onClick={onNew}><Plus size={18} /> New chat</button>
        <label className="search"><Search size={16} /><input type="search" placeholder="Search chats" aria-label="Search chats" value={q} onChange={(e) => setQ(e.target.value)} /></label>
        <nav aria-label="Conversations">
          <ul>
            {list.map((c) => (
              <li key={c.id} className={c.id === activeId ? 'on' : ''}>
                <button className="item" aria-current={c.id === activeId} onClick={() => onSelect(c.id)}>{c.title}</button>
                <button aria-label={`Rename ${c.title}`} onClick={() => { const t = prompt('Rename conversation', c.title); if (t?.trim()) onRename(c.id, t.trim()); }}><Pencil size={14} /></button>
                <button aria-label={`Delete ${c.title}`} onClick={() => { if (confirm('Delete this conversation?')) onDelete(c.id); }}><Trash2 size={14} /></button>
              </li>
            ))}
          </ul>
          {!list.length && <p className="muted">{q ? 'No matching chats.' : 'No conversations yet.'}</p>}
        </nav>
        <button className="item foot" onClick={onSettings}><Cog size={18} /> Settings</button>
      </aside>
    </>
  );
}
