import { useEffect, useRef, useState } from 'react';
import { ArrowUp, Globe, ImagePlus, Mic, Paperclip, Square, X } from 'lucide-react';
import type { Attachment, Mode, Settings } from '../types';
import { formatSize, resizeImage, uid } from '../lib/utils';

const OK = /\.(jpe?g|png|webp|pdf|txt|csv|docx)$/i;
const IMG = /\.(jpe?g|png|webp)$/i;

interface P {
  value: string; onChange: (v: string) => void; onSend: () => void; onStop: () => void; busy: boolean; editing: boolean;
  atts: Attachment[]; setAtts: (f: (p: Attachment[]) => Attachment[]) => void;
  settings: Settings; setSettings: (p: Partial<Settings>) => void; onError: (m: string) => void;
}
export default function Composer({ value, onChange, onSend, onStop, busy, editing, atts, setAtts, settings, setSettings, onError }: P) {
  const ta = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const imgRef = useRef<HTMLInputElement>(null);
  const rec = useRef<any>(null);
  const vr = useRef(value); vr.current = value;
  const [listening, setListening] = useState(false);

  useEffect(() => { const el = ta.current; if (el) { el.style.height = 'auto'; el.style.height = Math.min(el.scrollHeight, 200) + 'px'; } }, [value]);

  async function addFiles(list: FileList | null) {
    if (!list) return;
    const out: Attachment[] = [];
    for (const f of Array.from(list)) {
      if (!OK.test(f.name)) { onError(`Unsupported file type: ${f.name}`); continue; }
      const img = IMG.test(f.name);
      if (f.size > (img ? 8 : 10) * 1048576) { onError(img ? 'Image is too large (max 8 MB).' : 'File is too large (max 10 MB).'); continue; }
      try { out.push({ id: uid(), name: f.name, size: f.size, type: f.type, kind: img ? 'image' : 'file', file: f, dataUrl: img ? await resizeImage(f) : undefined }); }
      catch { onError('Something went wrong reading that file.'); }
    }
    if (out.length) setAtts((p) => [...p, ...out]);
  }

  function toggleVoice() {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) return onError('Voice input is not supported in this browser.');
    if (listening) { rec.current?.stop(); return; }
    const r = new SR(); r.lang = navigator.language; r.interimResults = false;
    r.onresult = (e: any) => { const t = Array.from(e.results).map((x: any) => x[0].transcript).join(' '); onChange((vr.current ? vr.current + ' ' : '') + t); };
    r.onerror = (e: any) => onError(e.error === 'not-allowed' || e.error === 'service-not-allowed' ? 'Microphone permission was denied.' : 'Voice input failed. Try again.');
    r.onend = () => setListening(false);
    rec.current = r; setListening(true); r.start();
  }

  return (
    <div className="composer"><div className="box">
      {atts.length > 0 && (
        <ul className="atts">{atts.map((a) => (
          <li key={a.id} className="chip">{a.dataUrl && <img src={a.dataUrl} alt="" />}<span className="nm">{a.name}</span><small>{formatSize(a.size)}</small>
            <button aria-label={`Remove ${a.name}`} onClick={() => setAtts((p) => p.filter((x) => x.id !== a.id))}><X size={14} /></button></li>
        ))}</ul>
      )}
      <textarea ref={ta} rows={1} aria-label="Message" value={value} placeholder={editing ? 'Edit your message…' : 'Message TIGYEX'}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey && settings.enterToSend && !e.nativeEvent.isComposing) { e.preventDefault(); onSend(); } }} />
      <div className="bar">
        <button aria-label="Attach file" onClick={() => fileRef.current?.click()}><Paperclip size={18} /></button>
        <button aria-label="Upload image" onClick={() => imgRef.current?.click()}><ImagePlus size={18} /></button>
        <button aria-label={listening ? 'Stop voice input' : 'Start voice input'} aria-pressed={listening} onClick={toggleVoice}><Mic size={18} /></button>
        <button aria-label="Web Search" aria-pressed={settings.webSearch} title="Web Search (needs a search backend)" onClick={() => setSettings({ webSearch: !settings.webSearch })}><Globe size={18} /></button>
        <select aria-label="Reasoning mode" value={settings.mode} onChange={(e) => setSettings({ mode: e.target.value as Mode })}>
          <option value="fast">Fast</option><option value="balanced">Balanced</option><option value="reasoning">Reasoning</option>
        </select>
        <span className="grow" />
        {busy ? <button className="send" aria-label="Stop generation" onClick={onStop}><Square size={16} /></button>
          : <button className="send" aria-label="Send message" onClick={onSend} disabled={!value.trim() && !atts.length}><ArrowUp size={18} /></button>}
      </div>
      <input ref={fileRef} type="file" hidden multiple accept=".pdf,.txt,.csv,.docx,.jpg,.jpeg,.png,.webp" onChange={(e) => { addFiles(e.target.files); e.target.value = ''; }} />
      <input ref={imgRef} type="file" hidden multiple accept="image/jpeg,image/png,image/webp" onChange={(e) => { addFiles(e.target.files); e.target.value = ''; }} />
    </div></div>
  );
}
