import { useEffect } from 'react';
import { X } from 'lucide-react';
import { MODELS, type Mode, type Settings } from '../types';

interface P { settings: Settings; set: (p: Partial<Settings>) => void; onClose: () => void; onClear: () => void }
export default function SettingsModal({ settings: s, set, onClose, onClear }: P) {
  useEffect(() => { const h = (e: KeyboardEvent) => e.key === 'Escape' && onClose(); window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h); }, [onClose]);
  return (
    <div className="overlay"><div className="modal" role="dialog" aria-modal="true" aria-labelledby="st">
      <header><h2 id="st">Settings</h2><button aria-label="Close settings" onClick={onClose}><X size={20} /></button></header>
      <section><h3>General</h3>
        <label>Theme<select value={s.theme} onChange={(e) => set({ theme: e.target.value as Settings['theme'] })}><option value="dark">Dark</option><option value="light">Light</option><option value="system">System</option></select></label>
        <label>Enter to send<input type="checkbox" checked={s.enterToSend} onChange={(e) => set({ enterToSend: e.target.checked })} /></label></section>
      <section><h3>AI</h3>
        <label>Default model<select value={s.model} onChange={(e) => set({ model: e.target.value })}>{MODELS.map((m) => <option key={m}>{m}</option>)}</select></label>
        <label>Reasoning mode<select value={s.mode} onChange={(e) => set({ mode: e.target.value as Mode })}><option value="fast">Fast</option><option value="balanced">Balanced</option><option value="reasoning">Reasoning</option></select></label>
        <label>Web Search<input type="checkbox" checked={s.webSearch} onChange={(e) => set({ webSearch: e.target.checked })} /></label></section>
      <section><h3>Developers</h3>
        <p className="muted">Status: {s.endpoint.trim() ? `Using backend at ${s.endpoint}` : 'No backend connected. Replies come from a local mock, not an AI.'}</p>
        <label>API endpoint<input type="url" placeholder="http://localhost:8787" value={s.endpoint} onChange={(e) => set({ endpoint: e.target.value })} /></label>
        <p className="muted">Never store provider API keys in the browser. Keep them in the backend's environment.</p></section>
      <section><h3>Privacy</h3>
        <p className="muted">Conversations and settings are stored only in this browser (localStorage). Nothing is synced.</p>
        <button className="danger" onClick={() => { if (confirm('Delete all local conversations?')) onClear(); }}>Clear local conversations</button></section>
    </div></div>
  );
}
