import { useState } from 'react';
import { Check, Copy, Pencil, RotateCw } from 'lucide-react';
import type { Message } from '../types';

interface P { m: Message; busy: boolean; canRegen: boolean; onEdit: () => void; onRegen: () => void }
export default function MessageView({ m, busy, canRegen, onEdit, onRegen }: P) {
  const [copied, setCopied] = useState(false);
  const copy = () => navigator.clipboard?.writeText(m.content).then(() => { setCopied(true); setTimeout(() => setCopied(false), 1200); });
  return (
    <article className={`msg ${m.role}`}>
      <div className="bubble">
        {m.attachments?.map((a) => a.dataUrl ? <img key={a.id} src={a.dataUrl} alt={a.name} /> : <span key={a.id} className="chip">{a.name}</span>)}
        {m.error ? <p className="text">Something went wrong.</p>
          : m.content ? <p className="text">{m.content}</p>
          : <span className="dots" role="status" aria-label="Thinking"><i /><i /><i /></span>}
      </div>
      <div className="actions">
        <time>{new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</time>
        {m.role === 'assistant' && m.content && !m.error && <button aria-label="Copy response" onClick={copy}>{copied ? <Check size={15} /> : <Copy size={15} />}</button>}
        {m.role === 'user' && !busy && <button aria-label="Edit message" onClick={onEdit}><Pencil size={15} /></button>}
        {canRegen && <button aria-label={m.error ? 'Retry' : 'Regenerate response'} onClick={onRegen}><RotateCw size={15} /></button>}
      </div>
    </article>
  );
}
