export type Role = 'user' | 'assistant';
export type Mode = 'fast' | 'balanced' | 'reasoning';
export interface Attachment { id: string; name: string; size: number; type: string; kind: 'image' | 'file'; dataUrl?: string; file?: File }
export interface Message { id: string; role: Role; content: string; createdAt: number; attachments?: Attachment[]; error?: boolean }
export interface Conversation { id: string; title: string; messages: Message[]; updatedAt: number }
export interface ChatRequest { messages: Message[]; model: string; mode: Mode; webSearch: boolean }
export interface Settings { theme: 'dark' | 'light' | 'system'; enterToSend: boolean; model: string; mode: Mode; webSearch: boolean; endpoint: string }
// Interface-level names only. They map to real models once a backend is connected.
export const MODELS = ['TIGYEX Auto', 'TIGYEX Fast', 'TIGYEX Reasoning', 'TIGYEX Vision'];
export const DEFAULT_SETTINGS: Settings = { theme: 'dark', enterToSend: true, model: MODELS[0], mode: 'balanced', webSearch: false, endpoint: '' };
