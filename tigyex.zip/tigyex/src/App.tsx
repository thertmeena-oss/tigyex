import { useEffect, useRef, useState } from 'react';
import { Menu } from 'lucide-react';
import Sidebar from './components/Sidebar';
import Composer from './components/Composer';
import MessageView from './components/MessageView';
import SettingsModal from './components/SettingsModal';
import { getProvider } from './services/ai';
import { KEYS, load, save } from './store/storage';
import { uid } from './lib/utils';
import { DEFAULT_SETTINGS, MODELS, type Attachment, type Conversation, type Message, type Settings } from './types';

const STARTERS = ['Explain a difficult concept', 'Write code for me', 'Analyze an image', 'Help me research something', 'Brainstorm an idea'];

export default function App() {
  const [convs, setConvs] = useState<Conversation[]>(() => load(KEYS.convs, []));
  const [settings, setS] = useState<Settings>(() => ({ ...DEFAULT_SETTINGS, ...load<Partial<Settings>>(KEYS.settings, {}) }));
  const [activeId, setActiveId] = useState<string | null>(null);
  const [draft, setDraft] = useState('');
  const [atts, setAtts] = useState<Attachment[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [drawer, setDrawer] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const abort = useRef<AbortController | null>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const active = convs.find((c) => c.id === activeId) ?? null;
  const setSettings = (p: Partial<Settings>) => setS((s) => ({ ...s, ...p }));
  const patch = (id: string, fn: (c: Conversation) => Conversation) => setConvs((p) => p.map((c) => (c.id === id ? fn(c) : c)));

  useEffect(() => {
    if (busy) return;
    const slim = convs.map((c) => ({ ...c, messages: c.messages.map((m) => ({ ...m, attachments: m.attachments?.map((a) => ({ ...a, dataUrl: undefined, file: undefined })) })) }));
    if (!save(KEYS.convs, slim)) setError('Could not save conversations locally (browser storage is full).');
  }, [convs, busy]);

  useEffect(() => {
    save(KEYS.settings, settings);
    const mq = matchMedia('(prefers-color-scheme: light)');
    const apply = () => { document.documentElement.dataset.theme = settings.theme === 'system' ? (mq.matches ? 'light' : 'dark') : settings.theme; };
    apply(); mq.addEventListener('change', apply);
    return () => mq.removeEventListener('change', apply);
  }, [settings]);

  useEffect(() => { endRef.current?.scrollIntoView({ block: 'end' }); }, [active?.messages]);

  async function run(id: string, history: Message[]) {
    const reply: Message = { id: uid(), role: 'assistant', content: '', createdAt: Date.now() };
    patch(id, (c) => ({ ...c, messages: [...history, reply], updatedAt: Date.now() }));
    const ctl = new AbortController(); abort.current = ctl; setError(null);
    const last = history[history.length - 1];
    setBusy(last.attachments?.some((a) => a.kind === 'image') ? 'Analyzing image...' : settings.webSearch ? 'Searching...' : settings.mode === 'fast' ? 'Generating...' : 'Thinking...');
    try {
      await getProvider(settings.endpoint).streamMessage(
        { messages: history, model: settings.model, mode: settings.mode, webSearch: settings.webSearch },
        (t) => patch(id, (c) => ({ ...c, messages: c.messages.map((m) => (m.id === reply.id ? { ...m, content: m.content + t } : m)) })),
        ctl.signal);
    } catch (e) {
      if ((e as Error).name !== 'AbortError') {
        setError(navigator.onLine ? 'Unable to connect to TIGYEX. Check the API endpoint in Settings, then retry.' : 'Network connection unavailable.');
        patch(id, (c) => ({ ...c, messages: c.messages.map((m) => (m.id === reply.id ? { ...m, error: true } : m)) }));
      }
    } finally { setBusy(null); abort.current = null; }
  }

  function send() {
    const text = draft.trim();
    if ((!text && !atts.length) || busy) return;
    const msg: Message = { id: uid(), role: 'user', content: text, createdAt: Date.now(), attachments: atts };
    let id = activeId; let base: Message[] = [];
    if (id && active) {
      base = active.messages;
      if (editingId) { const i = base.findIndex((m) => m.id === editingId); if (i >= 0) base = base.slice(0, i); }
    } else {
      id = uid();
      const c: Conversation = { id, title: (text || atts[0].name).slice(0, 40), messages: [], updatedAt: Date.now() };
      setConvs((p) => [c, ...p]); setActiveId(id);
    }
    setDraft(''); setAtts([]); setEditingId(null);
    run(id, [...base, msg]);
  }

  function regenerate() {
    if (!active || busy) return;
    const i = active.messages.map((m) => m.role).lastIndexOf('user');
    if (i >= 0) run(active.id, active.messages.slice(0, i + 1));
  }

  const msgs = active?.messages ?? [];
  return (
    <div className="app">
      <Sidebar convs={convs} activeId={activeId} open={drawer} onClose={() => setDrawer(false)}
        onNew={() => { setActiveId(null); setDraft(''); setAtts([]); setEditingId(null); setDrawer(false); }}
        onSelect={(id) => { setActiveId(id); setDrawer(false); }}
        onRename={(id, t) => patch(id, (c) => ({ ...c, title: t }))}
        onDelete={(id) => { setConvs((p) => p.filter((c) => c.id !== id)); if (activeId === id) setActiveId(null); }}
        onSettings={() => { setShowSettings(true); setDrawer(false); }} />
      <main className="main">
        <header className="top">
          <button className="menu" aria-label="Open sidebar" onClick={() => setDrawer(true)}><Menu size={20} /></button>
          <select aria-label="Model" value={settings.model} onChange={(e) => setSettings({ model: e.target.value })}>{MODELS.map((m) => <option key={m}>{m}</option>)}</select>
          <span className="status" role="status">{busy ?? (settings.endpoint.trim() ? 'Backend' : 'Local mock')}</span>
        </header>
        <div className="scroll"><div className="col">
          {msgs.length ? msgs.map((m, i) => (
            <MessageView key={m.id} m={m} busy={!!busy} canRegen={m.role === 'assistant' && i === msgs.length - 1 && !busy}
              onEdit={() => { setDraft(m.content); setEditingId(m.id); setAtts(m.attachments ?? []); }} onRegen={regenerate} />
          )) : (
            <div className="empty">
              <h1 className="wordmark">TIGYEX</h1>
              <p className="muted">Think. Create. Discover.</p>
              <div className="starters">{STARTERS.map((s) => <button key={s} onClick={() => setDraft(s)}>{s}</button>)}</div>
            </div>
          )}
          {error && <div className="error" role="alert"><span>{error}</span><button onClick={() => setError(null)}>Dismiss</button></div>}
          <div ref={endRef} />
        </div></div>
        <Composer value={draft} onChange={setDraft} onSend={send} onStop={() => abort.current?.abort()} busy={!!busy} editing={!!editingId}
          atts={atts} setAtts={setAtts} settings={settings} setSettings={setSettings} onError={setError} />
      </main>
      {showSettings && <SettingsModal settings={settings} set={setSettings} onClose={() => setShowSettings(false)} onClear={() => { setConvs([]); setActiveId(null); }} />}
    </div>
  );
}
