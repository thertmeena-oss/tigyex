# TIGYEX

Frontend foundation for a general-purpose AI platform. React + Vite + TypeScript, no UI framework.
**There is no AI in this repo.** Replies come from a local mock that says so. Connect a backend to get real answers.

## Run
```
npm install
npm run dev       # development
npm run build     # type-check + production build
npm run preview   # serve the build
```

## What is real (frontend)
Chats (create, rename, delete, search, persist in localStorage), streaming UI with stop / regenerate / retry / edit / copy,
model + reasoning selectors, Web Search toggle (state only), image and file attach with preview/size/remove and image resizing,
voice dictation via the Web Speech API (where supported; Chrome may send audio to its speech service after you press the mic),
dark/light/system theme, settings, drawer sidebar on mobile, error states, reduced-motion support.

## What needs a backend
Real AI replies, image analysis, document reading, web search (`POST /api/search`), memory, accounts, cloud storage.
Not built: Memory settings screen, profile menu, language and density settings.

## Connect your backend
`src/services/ai.ts` defines `AIProvider`. `MockAIProvider` is used until an API endpoint is set in Settings;
then `BackendProvider` calls `POST {endpoint}/api/chat` with JSON `{messages, model, mode, webSearch}` and reads a streamed plain-text response.
To use another transport, implement `AIProvider` and return it from `getProvider`. Provider adapters (OpenAI, Anthropic, Gemini, Qwen...) belong on the server.
Attachments carry `file` (original File) and `dataUrl` (resized preview); send files via multipart or an upload endpoint.

## Security
Browser -> your backend -> AI provider. Never put provider keys in this app or in `VITE_*` variables (they are public). See `.env.example` for backend-only variables.
